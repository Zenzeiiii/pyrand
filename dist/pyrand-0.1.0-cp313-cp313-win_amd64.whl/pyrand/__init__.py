from .pyrand import *

__doc__ = pyrand.__doc__
if hasattr(pyrand, "__all__"):
    __all__ = pyrand.__all__